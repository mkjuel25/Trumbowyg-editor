# Trumbowyg for Question2Answer

Question2Answer Wrapper for [Trumbowyg](https://github.com/Alex-D/Trumbowyg) - A lightweight WYSIWYG editor

> this is a beta code and not ready for your production site. Feel free to test in your local / dev environment and let us know if you are facing any issues

*readme will be updated soon*
